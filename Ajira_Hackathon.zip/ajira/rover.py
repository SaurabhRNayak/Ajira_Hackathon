from flask import Flask,request,render_template,Response
import json
import requests


app=Flask(__name__)

# Initial Environment cofiguration
env_conf={
    "temperature": 60,
    "humidity": 65,
    "solar-flare": False,
    "storm": False,
    "area-map": [
    [ "dirt", "dirt", "dirt", "water", "dirt" ],
    [ "dirt", "dirt", "water", "water", "water" ],
    [ "dirt", "dirt", "dirt", "water", "dirt" ],
    [ "dirt", "dirt", "dirt", "dirt", "dirt" ],
    [ "dirt", "dirt", "dirt", "dirt", "dirt" ]
    ]
}
env_conf_=env_conf.copy()

#initial rover configuration
rover_conf={
"scenarios": [
{
	"name": "battery-low",
	"conditions": [
	{
		"type": "rover",
		"property": "battery",
		"operator": "lte",
		"value": 2
		}
	],
	"rover": [
		{ "is": "immobile" }
	]
	},
{
	"name": "encountering-water",
	"conditions": [
	{
	"type": "environment",
	"property": "terrain",
	"operator": "eq",
	"value": "water"
	}
	],
	"rover": [
	{
	"performs": {
		"collect-sample": {
		"type": "water-sample",
		"qty": 2
			}
		}
	}
	]
},
{
	"name": "encountering-storm",
	"conditions": [
	{
		"type": "environment",
		"property": "storm",
		"operator": "eq",
		"value": True
	}
	],
	"rover": [
		{
			"performs": {
			"item-usage": {
			"type": "storm-shield",
			"qty": 1
				}
			}
		}
	]
}
],
"states": [
	{
	"name": "normal",
	"allowedActions": [ "move", "collect-sample" ]
	},
	{
	"name": "immobile",
	"allowedActions": [ "collect-sample" ]
	}
	],
"deploy-point": {
	"row": 3,
	"column": 2
	},
"initial-battery": 11,
"inventory": [
	{
	"type": "storm-shield",
	"quantity": 1,
	"priority": 1
	}
]
}

# Skeletal template of rover status response
status_template={
    "rover": {
    "location": {
    "row": None,
    "column": None
    },
    "battery": None,
    "inventory": 
    [
        # {
        # "type": "water-sample",
        # "qty": 2,
        # "priority": 2
        # }
    ]
    },
    "environment": {
        "temperature": None,
        "humidity": None,
        "solar-flare": None,
        "storm":None,
        "terrain": None
    }
}


global curr_point
global steps
global state
global battery
global mobility
global ja
curr_point=rover_conf['deploy-point'] # gives current coordinate of the rover
steps=0 # to monitor steps taken by rover to calculate kinetic enrgy (10 steps= 10 battery points)
state=None # checks whether the status is destroyed
battery=rover_conf['initial-battery'] # battery health
mobility=1 # flag for immobility of rover during storm or low battery


def response_temp():
    global ja
    status_template['rover']['location']={"row": curr_point['row'],
    "column": curr_point['column']}
    status_template['rover']['battery']=battery
    status_template['rover']['inventory']=rover_conf['inventory']
    status_template['environment']['temperature']=env_conf['temperature']
    status_template['environment']['humidity']=env_conf['humidity']
    status_template['environment']['solar-flare']=env_conf['solar-flare']
    status_template['environment']['storm']=env_conf['storm']
    status_template['environment']['terrain']=env_conf['area-map'][curr_point['row']][curr_point['column']]
    ja=json.dumps(status_template, indent=4)
    print(ja)
    print(status_template)

# Status of the rover
@app.route('/api/rover/status',methods=['POST','GET'])
def resp():
    global message
    global curr_point
    global ja
    global state
    response_temp()
    message=None
    if state=='destroyed':
        message="Rover destroyed"
        state="destroyed"
        
    return render_template("rover.html",map_=env_conf['area-map'],position=curr_point,message=message,response=ja)

# Initial environment config run
@app.route('/',methods=['POST','GET'])
@app.route('/api/environment/configure',methods=['POST','GET'])
def envconf():
    global state
    global ja
    env_conf=env_conf_.copy()
    if state=='destroyed':
        message="Environment Reset"
        state=None
        response_temp()
        return render_template("rover.html",map_=env_conf['area-map'],position=curr_point,message=message,response=ja)
    
    response_temp()
    return render_template("rover.html",map_=env_conf['area-map'],position=curr_point,response=ja)

# To modify the details in environment config via api
@app.route('/api/environment/patch/<change>',methods=['POST','GET'])
def envpat(change):
    global mobility
    global state
    if state=='destroyed':
        message="Rover destroyed"
        state="destroyed"
        response_temp()
        return render_template("rover.html",map_=env_conf['area-map'],position=curr_point,message=message,response=ja)
    change=change.split()
    for i in change:
        k,v=i.split(':')
        if k in env_conf.keys():
            if v=='True':
                v=True
            if v=='False':
                v=False                
            env_conf[k]=v
    if env_conf['storm']==True:
        print("kakakakak")
        for index,i in enumerate(rover_conf['inventory']):
            if i['type']=='storm-shield':
                j=i.copy()
                if j['quantity']>0:
                    mobility=0
                    j['quantity']-=1
                    rover_conf['inventory'][index]=j
                    if j['quantity']==0:
                        del(rover_conf['inventory'][index])
                    break
                    # response_temp()
                    # return render_template("rover.html",map_=env_conf['area-map'],position=curr_point,message=None,response=ja)
        else:
            mobility=1
            message="Rover destroyed"
            state="destroyed"
            del(rover_conf['inventory'][index])
            print(rover_conf)
            response_temp()
            return render_template("rover.html",map_=env_conf['area-map'],position=curr_point,message=message,response=ja)
    else:
        mobility=1
    response_temp()
    return render_template("rover.html",map_=env_conf['area-map'],position=curr_point,message=None,response=ja)

# to Move the rover in up|down|left|right directions
@app.route('/api/rover/move/<direction>',methods=['POST','GET'])
def mov(direction):
    global curr_point
    global steps
    global state
    global battery
    global mobility
    global ja
    message=None
    #storm flag check
    if state=="destroyed":
        message="Rover destroyed"
        response_temp()
        return render_template("rover.html",map_=env_conf['area-map'],position=curr_point,message=message,response=ja)
    elif env_conf['storm']==True:
        print("Cannot move during a storm")
        message="Cannot move during a storm"
        mobility=0
    
    #recharge checks
        #recharge if solarflare encountered
    elif env_conf['solar-flare']==True:
        battery=rover_conf['initial-battery']
        steps=0
        mobility=1
        #recharge if 10 steps taken
    elif steps==10:
        battery=10
        steps=0
    
    #Battery check
    else:
        for i in rover_conf['scenarios']:
            if i['name']=='battery-low':
                if battery<=i['conditions'][0]['value']:
                    message='Battery low, rover is immobile'
                    mobility=0
                    # return render_template("rover.html",map_=env_conf['area-map'],position=curr_point,message=message)
        
    #Map boundary condition check
    if mobility!=0:
        if direction.lower()=='up':
            if curr_point['row']-1>0:
                curr_point['row']-=1
                battery-=1
            else:
                message="Can move only within mapped area"    
                return render_template("rover.html",map_=env_conf['area-map'],position=curr_point,message=message,response=ja)
        elif direction.lower()=='down':
            if curr_point['row']+1<=len(env_conf['area-map']):
                curr_point['row']+=1
                battery-=1
            else:
                message="Can move only within mapped area"    
                return render_template("rover.html",map_=env_conf['area-map'],position=curr_point,message=message)
        elif direction.lower()=='left':
            if curr_point['column']+1>0:
                curr_point['column']-=1
                battery-=1
            else:
                message="Can move only within mapped area"    
                return render_template("rover.html",map_=env_conf['area-map'],position=curr_point,message=message)
        elif direction.lower()=='right':
            if curr_point['column']+1<=len(env_conf['area-map'][0]):
                curr_point['column']+=1
                battery-=1
            else:
                message="Can move only within mapped area"    
                return render_template("rover.html",map_=env_conf['area-map'],position=curr_point,message=message)
    terrain=env_conf['area-map'][curr_point['row']-1][curr_point['column']-1]
    inventory_=rover_conf['inventory']
    index=None
    if terrain.lower() =="rock":
        for index,i in enumerate(rover_conf['inventory']):
            if i['type']=='rock':
                if i['quantity']<3:
                    i['quantity']+=1
                    break
        else:
            entry={
                "type": "rock",
                "quantity": 1,
                "priority": 3
            }
            rover_conf['inventory'].append(entry)
    if terrain.lower() =="water":
        for index,i in enumerate(rover_conf['inventory']):
            if i['type']=='water':
                if i['quantity']<2:
                    i['quantity']+=1
                    break
        else:
            entry={
                "type": "water",
                "quantity": 1,
                "priority": 2
            }
            rover_conf['inventory'].append(entry)
    
    response_temp()
    return render_template("rover.html",map_=env_conf['area-map'],position=curr_point,message=message,response=ja)


if __name__=='__main__':

    app.run(debug=True)


"""
INSTRUCTIONS:
1. Run this python file rover.py (required modules: Flask,Json,requests)
2. First run "http://127.0.0.1:5000/" or "http://127.0.0.1:5000/api/environment/configure" on chrome (local host address may vary "http://127.0.0.1:5000" depending on prt availability)
3. For adding patch use "http://127.0.0.1:5000/api/environment/patch/<change>" (http://127.0.0.1:5000/api/environment/patch/storm:True or http://127.0.0.1:5000/api/environment/patch/storm:True temperature:40)
4. For getting rover status "http://127.0.0.1:5000/api/rover/status"
5. For getting rover movement  "http://127.0.0.1:5000/api/rover/move/<direction>" (http://127.0.0.1:5000/api/rover/move/up)
"""